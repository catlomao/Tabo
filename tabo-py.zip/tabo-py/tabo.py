#                         ╓,
#  made                   ▄▄▄▄▄▓▓▓▓█▌        ▐▓
#      by                 -`   ▓L       ,▄▓▄ ▐▓  ╓▄▄  ,▄
#✨                            ▓▌     ,█▀ ▐▓ ▐▓▄█" ▓"╔█"▀█╖
# catlomao                     ▓▌    ▄█ ,█▀▓ ]▓█ ▄█" ▓═  ▐█
#      ✨                 ,.,  █═    ██▓▀  █  ▀██╙   ▀█▄█▀
import json
import pyautogui

# Disable fail-safe
pyautogui.FAILSAFE = False

# Read tablet dimensions from JSON file
with open('config.json', 'r') as json_file:
    dimensions = json.load(json_file)
    tablet_width = dimensions['TABLET_WIDTH']
    tablet_height = dimensions['TABLET_HEIGHT']

# Get the screen size
screen_width, screen_height = pyautogui.size()

# Mapping function to convert mouse coordinates to tablet coordinates
def map_coordinates(x, y):
    tablet_x = int((x / screen_width) * tablet_width)
    tablet_y = int((y / screen_height) * tablet_height)
    return tablet_x, tablet_y

# Move the mouse to the tablet coordinates
def move_mouse_to_tablet(x, y):
    tablet_x, tablet_y = map_coordinates(x, y)
    pyautogui.moveTo(tablet_x, tablet_y)

# Example usage: Continuously move the mouse to the tablet coordinates
while True:
    # Get the current mouse position
    mouse_x, mouse_y = pyautogui.position()

    # Move the mouse to the tablet coordinates
    move_mouse_to_tablet(mouse_x, mouse_y)
